// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, cloudflare (build-only),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... } }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

// Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
// @cloudflare/vite-plugin builds from this — wrangler.jsonc main alone is insufficient.
// STATIC_SPA=1 npm run build  → bản tĩnh (dist/client) để Caddy/Nginx phục vụ, không cần Cloudflare/SSR.
const staticSpa = process.env.STATIC_SPA === "1";

export default defineConfig({
  ...(staticSpa ? { cloudflare: false as const } : {}),
  tanstackStart: staticSpa
    ? { spa: { enabled: true } }
    : { server: { entry: "server" } },
  vite: {
    preview: { host: "127.0.0.1" },
    server: {
      proxy: {
        "/api": {
          target: "http://localhost:8000",
          changeOrigin: true,
        },
      },
    },
  },
});
